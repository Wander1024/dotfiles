# contributing

If you are looking to add or update a formatter, please be sure to update both
`docs/neoformat.txt` as well as `README.md`. Thanks!
