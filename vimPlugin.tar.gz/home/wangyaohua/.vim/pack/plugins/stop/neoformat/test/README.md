# Neoformat Tests

Running tests

```bash
# inside test/

./install.sh

python3 -m virtualenv venv
pip install -r requirements.txt

pytest -v test.py
```
